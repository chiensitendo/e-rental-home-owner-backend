package com.e_rental.owner.enums;

public enum Role {
    ROLE_USER,
    ROLE_OWNER,
    ROLE_ADMIN
}
